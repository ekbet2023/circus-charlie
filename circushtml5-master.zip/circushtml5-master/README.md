Instructions

1) npm install grunt-cli
2) npm install
3) grunt